package majumundur.kena.layoutpertemuan3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.telecom.Call
import android.widget.Button
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import majumundur.kena.layoutpertemuan3.adapter.BannerAdapter
import majumundur.kena.layoutpertemuan3.data.ResultBannerTop
import majumundur.kena.layoutpertemuan3.data.ResultBannerTopItem
import okhttp3.internal.notify
import okhttp3.internal.notifyAll
import retrofit2.Response
import java.io.Console
import javax.security.auth.callback.Callback

class MainActivity : AppCompatActivity() {
    //1. declare adapter & recyclerview
    private lateinit var bannerAdapter: BannerAdapter
    lateinit var rvBanner:RecyclerView
    //====end 1
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val btnPage2 = findViewById<Button>(R.id.btnPage2)
        //2. setup nilai awal recycler view
        rvBanner = findViewById<RecyclerView>(R.id.rvBanner)
        rvBanner.adapter=BannerAdapter(null,this)
        //======end 2


        btnPage2.setOnClickListener {
            val intent = Intent(this,LoadImage::class.java).apply{}
            startActivity(intent)
        }

        NetworkConfig().getService()
            .getBannerTop()
            .enqueue(object : retrofit2.Callback<List<ResultBannerTopItem>> {
                override fun onFailure(call: retrofit2.Call<List<ResultBannerTopItem>>, t: Throwable) {
                    Toast.makeText(this@MainActivity, t.localizedMessage, Toast.LENGTH_SHORT).show()
                }
                override fun onResponse(
                    call: retrofit2.Call<List<ResultBannerTopItem>>,
                    response: Response<List<ResultBannerTopItem>>
                ) {

                    //3. jika data ditemukan, maka masukan response ke dalam adapter
                      bannerAdapter = BannerAdapter(response.body(),this@MainActivity)
                      rvBanner.adapter = bannerAdapter
                    bannerAdapter.notifyDataSetChanged()

                   // rvUser.adapter = UsersAdapter(response.body())

                   print(response.body().toString())
                }
            })

    }


}